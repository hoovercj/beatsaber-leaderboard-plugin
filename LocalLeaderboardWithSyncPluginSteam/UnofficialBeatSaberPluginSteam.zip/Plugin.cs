﻿using System;
using IllusionPlugin;
using System.Reflection;
using System.IO;
using System.Collections.Generic;

public class Plugin : IPlugin
{
    private string scores;
    private bool loaded = false;

    public string Name
    {
        get { return "Local Leaderboard Sync by Hoovercj"; }
    }

    public string Version
    {
        get { return "0.0.1"; }
    }

    private string LeaderboardFilePath
    {
        get
        {
            return String.Format(
                "{0}\\AppData\\LocalLow\\Hyperbolic Magnetism\\Beat Saber\\LocalLeaderboards.dat",
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
            );
        }
    }

    public void OnApplicationStart()
    {

    }

    public void OnApplicationQuit()
    {
        this.SaveThenPostScores();
    }

    public void OnLevelWasLoaded(int level)
    {
    }

    public void OnLevelWasInitialized(int level)
    {
        Log("Loaded level " + level);

        // When a level is initialized, save the score from the previous song.
        // It would be preferable to do whis when a level ends, but there is no event for that.
        this.SaveThenPostScores();

        // This is test code to illustrate what does and does not work with reflection
        this.loaded = true;
        if (!this.loaded)
        {
            this.LogLeaderboardsFileDirectly();
            this.LogScoresWithReflection();
            this.TestLocalLeaderboardsModelWithSync();
            this.OverwriteLocalLeaderboardsModel();
        }
    }

    public void OnUpdate()
    {
    }

    public void OnFixedUpdate()
    {

    }
    public string GetDirectoryPath(Assembly assembly)
    {
        string filePath = new Uri(assembly.CodeBase).LocalPath;
        return Path.GetDirectoryName(filePath);
    }

    private void SaveThenPostScores()
    {
        Log("SaveThenPostScores()");
        this.SaveScores();
        // SaveScores appears to work synchronously so this should be guaranteed to have
        // the most up-to-date scores
        this.PostScores();
    }

    private void SaveScores()
    {
        Log("SaveScores()");
        var writeTimeBeforeSave = File.GetLastWriteTime(this.LeaderboardFilePath);
        PersistentSingleton<LocalLeaderboardsModel>.instance.SaveData();
        var writeTimeAfterSave = File.GetLastWriteTime(this.LeaderboardFilePath);
        if (writeTimeBeforeSave.CompareTo(writeTimeAfterSave) < 0)
        {
            Log("File was saved");
        }
        else
        {
            Log("File is not yet saved");
        }
    }

    private void PostScores()
    {
        Log("PostScores()");
        var newScores = GetScoresString();
        if (newScores != this.scores)
        {
            scores = newScores;
            // TODO: post scores to endpoint with steam or oculus ID
            Log("TODO: Post scores");
        }
    }

    private string GetScoresString()
    {
        Log("GetScoresString()");
        return File.ReadAllText(this.LeaderboardFilePath);
    }

    private void Log(string data)
    {
        File.AppendAllText(@"PointSaberPluginLog.txt", data + Environment.NewLine);
    }

    #region TEST CODE

    /// <summary>
    /// Try to access the leaderboard file directly
    /// </summary>
    private void LogLeaderboardsFileDirectly()
    {
        Log("LogLeaderboardsFileDirectly()");
        try
        {
            var scoresText = this.GetScoresString();
            Log("Scores text is " + scoresText.Length + " characters long");
        }
        catch (Exception e)
        {
            Log("Exception:");
            Log(e.Message);
        }
    }

    /// <summary>
    /// Instantiate a new LocalLeaderboardsModelWithSync and call methods on it
    /// </summary>
    private void TestLocalLeaderboardsModelWithSync()
    {
        Log("TestLocalLeaderboardsModelWithSync()");
        try
        {
            // NOTE: No logs are ever called by these functions, so this apparently does _not_ work.
            var leaderboard = new LocalLeaderboardsModelWithSync();
            leaderboard.Awake();
            leaderboard.LoadData();
            leaderboard.LogScores();
        }
        catch (Exception e)
        {
            Log("Exception:");
            Log(e.Message);
        }
    }

    /// <summary>
    /// Try to set PersistentSingleton<LocalLeaderboardsModel>._instance = new LocalLeaderboardsModelWithSync()
    /// </summary>
    private void OverwriteLocalLeaderboardsModel()
    {
        Log("OverwriteLocalLeaderboardsModel");
        try
        {
            var leaderboardWithSync = new LocalLeaderboardsModelWithSync();
            leaderboardWithSync.Awake();
            leaderboardWithSync.LoadData();

            // Get the type info for PersistentSingleton<LocalLeaderboardsModel>
            var leaderboardModelType = typeof(PersistentSingleton<>)
                .MakeGenericType(typeof(LocalLeaderboardsModel));

            // Get the private field PersistentSingleton<LocalLeaderboardsModel>._instance
            var field = leaderboardModelType.GetField("_instance", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);
            Log(field.Name);

            // Set PersistentSingleton<LocalLeaderboardsModel>._instance = new LocalLeaderboardsModelWithSync()
            field.SetValue(leaderboardModelType, leaderboardWithSync, BindingFlags.SetField, null, System.Globalization.CultureInfo.InvariantCulture);
            Log("Value set");

            var instance = PersistentSingleton<LocalLeaderboardsModel>.instance;
            instance.LoadData();
        }
        catch (Exception e)
        {
            Log("Exception:");
            Log(e.Message);
        }

    }

    /// <summary>
    /// Log scores via reflection. This is a fallback in case accessing scores via a custom leaderboard object does not work
    /// </summary>
    private void LogScoresWithReflection()
    {
        Log("LogScoresWithReflection()");
        try
        {
            var instance = PersistentSingleton<LocalLeaderboardsModel>.instance;
            var leaderboardModelType = instance.GetType();
            var fields = leaderboardModelType.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance | BindingFlags.Static);

            foreach (FieldInfo field in fields)
            {
                if (field.Name == "_leaderboardsData")
                {
                    // TODO: this fails on casting if I cast to List<object> but I don't
                    // have access to the real type which is List<LeaderboardData>
                    //List<object> value = (List<object>)field.GetValue(instance);
                    //foreach(object score in value)
                    //{
                    //    Log(score.ToString());
                    //}
                    Log(field.GetValue(instance).ToString());
                }
            }
        }
        catch (Exception e)
        {
            Log("Exception:");
            Log(e.Message);
        }
    }

    #endregion TEST CODE
}